package com.example.recycleview;

public class Dj {
    String genre;
    String name;
    String email;
    String phone;

    public String getGenre() {
        return genre;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }
}
