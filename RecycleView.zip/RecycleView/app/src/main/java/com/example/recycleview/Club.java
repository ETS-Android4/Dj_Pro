package com.example.recycleview;

public class Club {
    String genre;
    String name;
    String picture;
    String phone;
    String address;

    public String getGenre() {
        return genre;
    }

    public String getName() {
        return name;
    }

    public String getPicture() {
        return picture;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }
}
